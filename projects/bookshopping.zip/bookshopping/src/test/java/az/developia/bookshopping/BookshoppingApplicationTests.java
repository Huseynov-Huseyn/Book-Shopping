package az.developia.bookshopping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookshoppingApplicationTests {

	@Test
	void contextLoads() {
	}

}
